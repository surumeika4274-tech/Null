# NULL — Ash Mist Forest (Free browser prototype)

A single-page Three.js prototype designed for iPhone Safari and desktop. It has a real-time 3D scene, keyboard/touch movement, a chasing wolf, attack/dodge, targetable part HP, interruptible NULL transfer, ability ledger with unique IDs, equipment, an ANCHOR stabilization station, and versioned localStorage save/load validation.

## Run locally
Open `index.html` from a static web server. Since it imports Three.js from jsDelivr, an internet connection is required. Opening as a local `file://` URL may be blocked by some browsers.

## Publish for free with GitHub Pages
1. Create a new **public** GitHub repository named `NULL-free-build` (or another name).
2. Upload `index.html` and `README.md` to the repository root.
3. In the repository, open **Settings → Pages**.
4. Under Build and deployment, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
5. Wait for the published URL shown on the Pages settings page. Open it in Safari.

## Prototype notes
- This is a compact vertical slice, not a complete RPG.
- Art uses low-poly procedural primitives; there are no external model assets.
- The damage formula is provisional: `max(1, floor(power * attack / (100 + defense)))`.
- Save data is local to the current browser/device, not cloud-synced.
- The demo needs internet access to load Three.js from the CDN.
- No automated browser build/test has been run in this environment. Test controls and gameplay after publishing.
